#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <stdlib.h>
#include "mdadm.h"
#include "jbod.h"
#include "net.h"


uint32_t encode_operation(jbod_cmd_t cmd, int disk_num, int block_num) {
  uint32_t op = cmd << 26 | disk_num << 22 | block_num; 
  return op;
}

void translate_address(uint32_t linear_address, int *disk_num, int *block_num, int *offset){
  int block_remainder=0;
  *disk_num = linear_address / JBOD_DISK_SIZE;
  block_remainder = linear_address % JBOD_DISK_SIZE;
  *block_num = block_remainder / JBOD_BLOCK_SIZE;
  *offset = block_remainder % JBOD_BLOCK_SIZE;  
}

int seek(int disk_num, int block_num){
  uint32_t op;
  uint32_t ops;  
  op = encode_operation(JBOD_SEEK_TO_DISK, disk_num, 0);
  ops = encode_operation(JBOD_SEEK_TO_BLOCK, 0, block_num);
  jbod_client_operation(op, NULL);
  jbod_client_operation(ops, NULL);
  return 1;
}

int min_function(int n, int n2){
if (n>n2){
  return n2;
  }
else if(n==n2){
  return n;
  }
else{
  return n;
}
}

int mounted = 0; 
int mdadm_mount(void) {
  uint32_t op = encode_operation(JBOD_MOUNT, 0, 0); 
  int value = jbod_client_operation(op, NULL);
  if (value == 0){
    mounted = 1;
    return 1;
  }
  return -1;
}

int mdadm_unmount(void) {
  uint32_t last_op = encode_operation(JBOD_UNMOUNT,0, 0); //last command called so its on last disk, last block
  int value = jbod_client_operation(last_op, NULL);
  if (value == 0){
    mounted =0;
    return 1;
  }
  return -1;
}

int mdadm_read(uint32_t addr, uint32_t len, uint8_t *buf) {
  int disk_num, block_num, offset;
  if (mounted == 0 || len > 1024 || (len && buf == NULL) || addr + len >= (JBOD_NUM_DISKS * JBOD_DISK_SIZE)){
    return -1; 
  }
 
  int total = len;
  int data_read = 0;
  int current_address = addr;
  int sumDR = 0;
  int counter = 0;
  uint8_t buf1[256];
  while (current_address < addr+len){
    translate_address(current_address, &disk_num, &block_num, &offset);
    seek(disk_num, block_num);
  
    if (cache_enabled()==true){
      if ( cache_lookup(disk_num, block_num, buf1) == 1){
        memcpy(buf,buf1,256-offset);
	      return 1;
	    }
	} 

    uint32_t op = encode_operation(JBOD_READ_BLOCK, 0, 0);
    jbod_client_operation(op,buf1);
    cache_insert(disk_num, block_num, buf1);
    
   if (counter == 0){
      memcpy(buf+sumDR, buf1+offset, min_function((JBOD_BLOCK_SIZE - offset),len));
      data_read = min_function((JBOD_BLOCK_SIZE - offset),len);
      counter += 1; 	
    }
   else if (total < JBOD_BLOCK_SIZE){
      memcpy(buf+sumDR, buf1, total);
      data_read = total;
    }
  else{
      memcpy(buf+sumDR, buf1, JBOD_BLOCK_SIZE);
      data_read = JBOD_BLOCK_SIZE; 
    }
   
    sumDR = sumDR + data_read;
    total = total - data_read;
    current_address = current_address + data_read;
  }
  return len;
}

int mdadm_write(uint32_t addr, uint32_t len, const uint8_t *buf) {
  if (mounted == 0 || len > 1024 || (len && buf == NULL) || (addr+len) > (JBOD_NUM_DISKS * JBOD_DISK_SIZE)){
    return -1;
  }
  
  int disk_num, block_num, offset;
  int total = len;
  int data_read = 0;
  int current_address = addr;
  int sumDR = 0;
  int counter = 0;
  uint8_t buf1[256];

  while (current_address<addr+len){ 
    translate_address(current_address, &disk_num, &block_num, &offset);
    seek(disk_num, block_num); 
    uint32_t op = encode_operation(JBOD_READ_BLOCK, 0, 0); 
    jbod_client_operation(op,buf1); 
    
   if (counter == 0){
    memcpy(buf1+offset,buf+sumDR ,min_function((JBOD_BLOCK_SIZE - offset),len)); 
    seek(disk_num, block_num); 
    uint32_t ops = encode_operation(JBOD_WRITE_BLOCK, 0, 0); 
    jbod_client_operation(ops,buf1);
    data_read = min_function((JBOD_BLOCK_SIZE - offset),len); 
    counter += 1;                                                                            
    }
   else if (total < JBOD_BLOCK_SIZE){
    memcpy(buf1, buf+sumDR, total);
    seek(disk_num, block_num);
    uint32_t ops = encode_operation(JBOD_WRITE_BLOCK, 0, 0);
    jbod_client_operation(ops,buf1);
    data_read = total;
    }
  else{
    memcpy(buf1, buf+sumDR, JBOD_BLOCK_SIZE); 
    uint32_t ops = encode_operation(JBOD_WRITE_BLOCK, 0, 0);
    jbod_client_operation(ops,buf1);
    data_read = JBOD_BLOCK_SIZE;
    }

  sumDR = sumDR + data_read;
  total = total - data_read;                                                                              
  current_address = current_address + data_read; 
  }

 return len;
 }
